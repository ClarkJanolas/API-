

<?php $__env->startSection('content'); ?>
This is registration form
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud_application\resources\views/registration-form.blade.php ENDPATH**/ ?>