<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Songs;

class SongsController extends Controller
{
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'song_title' => 'required',
            'song_artist' => 'required',
            'song_genre' => 'required',
            'song_release' => 'required',
            'song_ratings' => 'required'
        ]);

        if($validator->fails()){
            return response()->json(['created' => false, 'errors' => $validator->errors(), 400]);
        }

        Songs::create($request->all());
        return response()->json(['created' => true, 'message' => 'A song is successfully added to the database', 201]);
    }

    public function find($id)
    {
        $songs = Songs::find($id);
        if(!$songs){
            return response()->json(['found' => false, 'message' => "No Song is found with an ID of $id"], 404);
        }
        return response()->json(['found' => true, 'Song Information' => $songs]);
    }

    public function getAllSongs() {
        return response()->json(Songs::all(), 200);
    }

    public function delete($id) {
        $songs = Songs::find($id);
        if(is_null($songs)) {
            return response()->json(['deleted' => false, 'message' => "No Song is found with an ID of $id"], 404);
        }
        $songs->delete();
        return response()->json(['deleted' => true, 'message' => "Song with ID $id is deleted in the database"], 204);
    }

    public function update(Request $request,$id) {
        $songs = Songs::find($id);
        if(is_null($songs)) {
            return response()->json(['found' => false, 'message' => "No Song is found with ID of $id"], 404);
        }
        $songs->update($request->all());
        return response($songs, 200);
    }

}
